package com.hun;



import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


public class DateClass {
	public static ObservableList<ScheduleClass> schedule = FXCollections.observableArrayList();

}
